const { resolve } = require("path");

module.exports = (RED) => {
  const http = require("https");
  const urlencode = require("urlencode");
  let output = { payload: null };
  //const token = "Ufc7pdoxsGlL3ShSrcdIaiG0VvsmC7xe";

  const sendRequest = (accessToken, message, recipient) => {
    let url =
      "https://api.smsmode.com/http/1.6/sendSMS.do?accessToken=" +
      accessToken +
      "&message=" +
      urlencode(message, "ISO-8859-15") +
      "&numero=" +
      recipient;

    return new Promise((resolve, reject) => {
      http
        .get(url, (response) => {
          let apiResponse = "";
          response.on("data", (chunk) => {
            apiResponse += chunk;
          });
        })
        .on("error", (error) => {
          reject("An error occured: " + error);
        });
      if (
        accessToken != undefined &&
        recipient != undefined &&
        message != undefined
      ) {
        output.payload = {
          message: message,
          destinataire: recipient,
          status: "succes",
        };
        resolve();
      } else {
        reject();
      }
    });
  };

  function SMS(config) {
    RED.nodes.createNode(this, config);
    let node = this;
    node.on("input", (msg) => {
      sendRequest(
        msg.payload.token,
        msg.payload.message,
        msg.payload.destinataire
      )
      .then(
        node.send(output)
      )
      .catch((err) => {
        if (err != undefined) {
          output.payload = {
            error: err,
          };
          node.send(output);
        }
      });
    });
  }
  RED.nodes.registerType("send-sms", SMS);
};
