module.exports = function(RED) {
    const http = require('https');
    const urlencode = require('urlencode');
    //const token = "Ufc7pdoxsGlL3ShSrcdIaiG0VvsmC7xe";

    const sendRequest = async (accessToken, message, recipient) => {
        let url = 'https://api.smsmode.com/http/1.6/sendSMS.do?accessToken=' + accessToken +
         '&message=' + urlencode(message,'ISO-8859-15') + '&numero=' + recipient;
  
         http.get(url, (response) => {
            let apiResponse = ''
            response.on('data', (chunk) =>{
                apiResponse += chunk;
            })
            .on('end', () => {
                console.log(apiResponse);
            });
         })
         .on('error', (error)=>{
             console.log(error);
         });
    };
    
    function SMS(config) {
        RED.nodes.createNode(this,config);
        var node = this;
        node.on('input', function(msg) {
            sendRequest(node.id.token, msg.payload.message, msg.payload.recipient);
            node.send(msg);
        });
    }
    RED.nodes.registerType("sms-mode",SMS, {
        id:{
            token: {type: "text"}
        }
    });
}